# Backend TORIPE IA V6.0

Node.js 20+, Express, Gemini API et SQLite.

```bash
npm install
cp .env.example .env
# renseigner GEMINI_API_KEY dans .env
npm start
```

Routes : `GET /`, `GET /health`, `GET /api/config`, `POST /api/chat`, `GET /api/history?client_id=...`, `POST /api/generate-image`.

La clé Gemini reste uniquement sur le serveur. Si `TORIPE_ACCESS_TOKEN` est défini, les appels protégés doivent envoyer `Authorization: Bearer <jeton>`.

SQLite crée automatiquement le fichier indiqué par `DB_PATH`. Configure un stockage persistant chez l'hébergeur si tu veux conserver les conversations après redéploiement. La génération d'image est un adaptateur facultatif, et non un moteur image intégré.


## Service client configurable

L'application affiche un bouton « Contacter le service client », puis les choix Email,
WhatsApp et Appel. Les coordonnées ne sont pas imprimées en clair dans l'interface.
Le message saisi est prérempli dans l'application Email ou WhatsApp du téléphone.
L'appel ouvre le composeur téléphonique.

Variables initiales : `SUPPORT_PHONE`, `SUPPORT_WHATSAPP` (format international,
chiffres uniquement), `SUPPORT_EMAIL`, `SUPPORT_EMAIL2`.
Configure obligatoirement `TORIPE_ADMIN_TOKEN` dans les secrets Render.

- `GET /api/support` : configuration utilisée par les boutons de contact.
- `GET /api/admin/support` : lire les coordonnées (jeton administrateur requis).
- `POST /api/admin/support` : modifier les coordonnées sans redéployer
  (jeton administrateur requis).

Exemple JSON : `{"phone":"0149000000","whatsapp":"229014900000","email":"nouveau@example.com","email2":"autre@example.com"}`.
Les modifications API sont stockées dans SQLite : configure un disque persistant Render.
Ne partage jamais le jeton administrateur.


## Gemini + ChatGPT / GPT-6

Dans Render > Environment, configure au moins une clé : `GEMINI_API_KEY` ou `OPENAI_API_KEY`. Pour activer les deux moteurs, configure les deux. Les clés restent exclusivement côté serveur.

- `GEMINI_MODEL` : modèle Gemini à utiliser.
- `GPT_MODEL` : modèle OpenAI rapide (défaut `gpt-4.1-mini`).
- `GPT_BALANCED_MODEL` : modèle équilibré (défaut `gpt-4.1`).
- `GPT_PRO_MODEL` : modèle de raisonnement avancé (défaut `o3`).

Dans l’application V5.0, le moteur est présenté sous la marque TORIPE et sélectionné automatiquement côté serveur. Les niveaux Instant, Moyen, Élevé, Très élevé et Pro règlent le niveau de raisonnement OpenAI et le modèle associé. Le niveau Pro n'est pas une offre ChatGPT Pro : il sélectionne seulement le modèle API configuré. Double IA exige les deux clés. L'utilisation de l'API OpenAI n'est pas gratuite par défaut et est facturée selon les tarifs du fournisseur.

La taille des écritures est réglable depuis Paramètres et enregistrée sur l'appareil.


## Analyse d'images dans le chat (V6.0)

Le chat accepte les images jointes (8 Mo maximum) et les transmet au modèle multimodal
Gemini ou OpenAI configuré. Les clés restent côté serveur. Les fichiers PDF/DOCX se lisent
depuis l'espace Documents dans l'application ; les petits fichiers texte peuvent être
joints directement au chat.

Les identifiants de modèles OpenAI par défaut sont des valeurs de départ configurables :
vérifie toujours qu'ils sont disponibles pour ton compte API. Le niveau de réflexion
avancé ne transforme pas un modèle standard en modèle de raisonnement.
