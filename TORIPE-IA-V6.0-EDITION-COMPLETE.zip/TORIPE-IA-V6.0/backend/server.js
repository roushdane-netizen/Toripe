import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ACCESS_TOKEN = process.env.TORIPE_ACCESS_TOKEN || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const GPT_MODEL = process.env.GPT_MODEL || 'gpt-4.1-mini';
const GPT_BALANCED_MODEL = process.env.GPT_BALANCED_MODEL || 'gpt-4.1';
const GPT_PRO_MODEL = process.env.GPT_PRO_MODEL || 'o3';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, process.env.DB_PATH || './data/toripe.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, client_id TEXT NOT NULL, role TEXT NOT NULL,
  content TEXT NOT NULL, provider TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_conversations_client ON conversations(client_id, id);
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);
const saveMessage = db.prepare('INSERT INTO conversations (client_id, role, content, provider) VALUES (?, ?, ?, ?)');

app.disable('x-powered-by');
app.use(cors({ origin: true, methods: ['GET','POST','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
app.use(express.json({ limit: '20mb' }));
function auth(req, res, next) {
  if (!ACCESS_TOKEN) return next();
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (token !== ACCESS_TOKEN) return res.status(401).json({ error: 'Accès refusé. Vérifie la clé d’accès TORIPE.' });
  next();
}
const geminiKey = () => process.env.GEMINI_API_KEY || '';

const openaiKey = () => process.env.OPENAI_API_KEY || '';
const provider = () => [geminiKey() && 'Gemini', openaiKey() && 'OpenAI'].filter(Boolean).join(' + ') || 'demo';

// Coordonnées du support gérées côté serveur.
const defaultSupport = {
  phone: process.env.SUPPORT_PHONE || '0149322342',
  whatsapp: process.env.SUPPORT_WHATSAPP || '2290149322342',
  email: process.env.SUPPORT_EMAIL || 'roushdane60@gmail.com',
  email2: process.env.SUPPORT_EMAIL2 || 'roushdane0@gmail.com'
};
const getSetting = db.prepare('SELECT value FROM app_settings WHERE key = ?');
const setSetting = db.prepare(`INSERT INTO app_settings(key,value,updated_at)
  VALUES(?,?,CURRENT_TIMESTAMP)
  ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP`);
function getSupportContacts() {
  const read = (key, fallback) => getSetting.get(key)?.value ?? fallback;
  return {
    phone: read('support_phone', defaultSupport.phone),
    whatsapp: read('support_whatsapp', defaultSupport.whatsapp),
    email: read('support_email', defaultSupport.email),
    email2: read('support_email2', defaultSupport.email2)
  };
}
function adminOnly(req, res, next) {
  const secret = process.env.TORIPE_ADMIN_TOKEN || '';
  if (!secret) return res.status(503).json({ error: 'Gestion administrateur désactivée : configure TORIPE_ADMIN_TOKEN dans les secrets du serveur.' });
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token || token !== secret) return res.status(401).json({ error: 'Accès administrateur refusé.' });
  next();
}
app.get('/api/support', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, contacts: getSupportContacts() });
});
app.get('/api/admin/support', adminOnly, (_req, res) => {
  res.json({ ok: true, contacts: getSupportContacts() });
});
app.post('/api/admin/support', adminOnly, (req, res) => {
  const body = req.body || {};
  const fields = { support_phone: 'phone', support_whatsapp: 'whatsapp', support_email: 'email', support_email2: 'email2' };
  for (const [key, field] of Object.entries(fields)) {
    if (body[field] !== undefined) {
      const value = String(body[field]).trim();
      if (value.length > 160 || /[\\r\\n]/.test(value)) return res.status(400).json({ error: `Valeur invalide pour ${field}.` });
      setSetting.run(key, value);
    }
  }
  res.json({ ok: true, message: 'Coordonnées du service client mises à jour.', contacts: getSupportContacts() });
});

app.get('/', (_req, res) => res.json({ name: 'TORIPE IA CRÉATEUR API', version: '2.0.0', status: 'online', endpoints: ['/health','/api/config','/api/chat','/api/history','/api/generate-image','/api/support','/api/admin/support'] }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'TORIPE IA CRÉATEUR V2.0', provider: provider(), database: 'sqlite', time: new Date().toISOString() }));
app.get('/api/config', (_req, res) => res.json({ ok: true, provider: provider(), model: GEMINI_MODEL, geminiConfigured: !!geminiKey(), openaiConfigured: !!openaiKey(), aiConfigured: !!(geminiKey() || openaiKey()), webSearch: process.env.ENABLE_WEB_SEARCH === 'true', imageGeneration: !!process.env.IMAGE_API_URL, imageUnderstanding: !!(geminiKey() || openaiKey()), documentAnalysis: !!(geminiKey() || openaiKey()), database: 'sqlite' }));

async function callGemini({ message, history = [], attachment_text = '', attachment_name = '', webSearch = false }) {
  if (!geminiKey()) {
    if (process.env.MOCK_AI === 'true') return `Mode démonstration TORIPE IA CRÉATEUR. Ta demande a bien été reçue : ${message || 'Analyse du document'}. Pour activer la vraie IA, ajoute GEMINI_API_KEY dans les variables secrètes du serveur.`;
    const e = new Error('Le serveur est en ligne, mais GEMINI_API_KEY n’est pas configurée. Ajoute la clé Gemini dans les variables du serveur.'); e.status = 503; throw e;
  }
  const contents = [];
  for (const item of (Array.isArray(history) ? history.slice(-16) : [])) {
    if (!['user','assistant','model'].includes(item.role)) continue;
    const role = item.role === 'assistant' ? 'model' : item.role;
    const content = String(item.content || '').slice(0, 12000);
    if (content) contents.push({ role, parts: [{ text: content }] });
  }
  let prompt = String(message || '');
  if (attachment_text) prompt += `\n\nContenu du fichier ${attachment_name || ''} :\n${String(attachment_text).slice(0, 50000)}`;
  const userParts = [{ text: prompt || 'Analyse le document joint.' }];
  if (args.attachment_data && args.attachment_mime && String(args.attachment_mime).startsWith('image/')) {
    userParts.push({ inline_data: { mime_type: args.attachment_mime, data: args.attachment_data } });
  }
  contents.push({ role: 'user', parts: userParts });
  const body = { contents, systemInstruction: { parts: [{ text: 'Tu es TORIPE IA CRÉATEUR, assistant francophone polyvalent. Réponds clairement, pédagogiquement et honnêtement. Pour les exercices, explique les étapes. Pour la création, propose des contenus originaux, structurés et directement exploitables. Pour le code, fournis des solutions exécutables et signale les limites.' }] }, generationConfig: { temperature: 0.7, maxOutputTokens: 8192 } };
  if (webSearch && process.env.ENABLE_WEB_SEARCH === 'true') body.tools = [{ google_search: {} }];
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(geminiKey())}`;
  const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const e = new Error(data.error?.message || `Gemini a répondu HTTP ${response.status}.`); e.status = 502; throw e; }
  let answer = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n').trim();
  const chunks = data.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const links = chunks.map(x => x.web).filter(x => x?.uri).map(x => `- ${x.title || 'Source'} : ${x.uri}`);
  if (links.length) answer += '\n\nSources :\n' + [...new Set(links)].join('\n');
  if (!answer) throw new Error('Gemini a renvoyé une réponse vide.');
  return answer;
}
async function callOpenAI({ message, history = [], attachment_text = '', attachment_name = '', webSearch = false, thinking = 'medium' }) {
  if (!openaiKey()) { const e = new Error('OPENAI_API_KEY n’est pas configurée sur le serveur.'); e.status = 503; throw e; }
  const effort = ({ instant: 'low', medium: 'medium', high: 'high', xhigh: 'high', pro: 'high' })[thinking] || 'medium';
  const model = thinking === 'pro' ? GPT_PRO_MODEL : (thinking === 'high' || thinking === 'xhigh') ? GPT_BALANCED_MODEL : GPT_MODEL;
  const input = [];
  for (const item of (Array.isArray(history) ? history.slice(-16) : [])) {
    if (!['user','assistant','model'].includes(item.role)) continue;
    const role = item.role === 'model' ? 'assistant' : item.role;
    const content = String(item.content || '').slice(0, 12000);
    if (content) input.push({ role, content });
  }
  let prompt = String(message || '');
  if (attachment_text) prompt += `\n\nContenu du fichier ${attachment_name || ''} :\n${String(attachment_text).slice(0, 50000)}`;
  const userContent = [{ type: 'input_text', text: prompt || 'Analyse le document joint.' }];
  if (args.attachment_data && args.attachment_mime && String(args.attachment_mime).startsWith('image/')) {
    userContent.push({ type: 'input_image', image_url: `data:${args.attachment_mime};base64,${args.attachment_data}` });
  }
  input.push({ role: 'user', content: userContent });
  const body = {
    model,
    instructions: 'Tu es TORIPE IA, assistant francophone polyvalent. Réponds clairement, pédagogiquement et honnêtement. Pour les exercices, explique les étapes. Pour la création, propose des contenus originaux, structurés et directement exploitables. Pour le code, fournis des solutions exécutables et signale les limites.',
    input,
    max_output_tokens: 8192
  };
  if (/^(o1|o3|o4)/.test(model)) body.reasoning = { effort: effort === 'max' ? 'high' : effort };
  if (webSearch && process.env.ENABLE_WEB_SEARCH === 'true') body.tools = [{ type: 'web_search' }];
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${openaiKey()}` }, body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const e = new Error(data.error?.message || `OpenAI a répondu HTTP ${response.status}.`); e.status = 502; throw e; }
  const answer = data.output_text || (data.output || []).flatMap(x => x.content || []).map(x => x.text || '').join('\n').trim();
  if (!answer) throw new Error('OpenAI a renvoyé une réponse vide.');
  return { answer, model };
}
async function runProvider({ provider: requested = 'auto', ...args }) {
  if (requested === 'double') {
    if (!geminiKey() || !openaiKey()) { const e = new Error('Le mode Double IA exige GEMINI_API_KEY et OPENAI_API_KEY configurées sur le serveur.'); e.status = 503; throw e; }
    const [g, o] = await Promise.all([
      callGemini(args).then(answer => ({ name: 'Gemini', answer })),
      callOpenAI(args).then(result => ({ name: 'ChatGPT', answer: result.answer, model: result.model }))
    ]);
    const synthesis = await callGemini({ message: 'Compare ces deux réponses et rédige une synthèse fiable, en signalant les différences utiles.\n\nRÉPONSE GEMINI :\n' + g.answer + '\n\nRÉPONSE CHATGPT :\n' + o.answer, history: [] });
    return { reply: 'COMPARAISON DES MOTEURS\n\nGEMINI :\n' + g.answer + '\n\nCHATGPT :\n' + o.answer + '\n\nSYNTHÈSE TORIPE :\n' + synthesis, provider: 'Gemini + OpenAI', model: `${GEMINI_MODEL} + ${o.model}` };
  }
  if (requested === 'gemini') return { reply: await callGemini(args), provider: 'Gemini', model: GEMINI_MODEL };
  if (requested === 'openai') { const result = await callOpenAI(args); return { reply: result.answer, provider: 'OpenAI', model: result.model }; }
  // Auto: prefer Gemini if configured, otherwise OpenAI.
  if (geminiKey()) return { reply: await callGemini(args), provider: 'Gemini', model: GEMINI_MODEL };
  if (openaiKey()) { const result = await callOpenAI(args); return { reply: result.answer, provider: 'OpenAI', model: result.model }; }
  const e = new Error('Aucun moteur IA configuré. Ajoute GEMINI_API_KEY ou OPENAI_API_KEY dans les variables Render.'); e.status = 503; throw e;
}
app.options('/api/chat', (_req, res) => res.sendStatus(204));
app.post('/api/chat', auth, async (req, res) => {
  try {
    const { message, history, attachment_text, attachment_name, attachment_data, attachment_mime, web_search, provider: requestedProvider, thinking } = req.body || {};
    if (attachment_data && (!attachment_mime || !String(attachment_mime).startsWith('image/'))) return res.status(400).json({ error: 'Type de pièce jointe image invalide.' });
    if (attachment_data && String(attachment_data).length > 11_000_000) return res.status(413).json({ error: 'Image trop volumineuse. Réduis-la à moins de 8 Mo.' });
    const clientId = String(req.body?.client_id || 'anonymous').slice(0, 100);
    if (!String(message || '').trim() && !attachment_text) return res.status(400).json({ error: 'Le message est vide.' });
    const result = await runProvider({ provider: requestedProvider || 'auto', message, history, attachment_text, attachment_name, attachment_data, attachment_mime, webSearch: !!web_search, thinking: thinking || 'medium' });
    if (message) saveMessage.run(clientId, 'user', String(message).slice(0, 20000), result.provider);
    saveMessage.run(clientId, 'assistant', result.reply.slice(0, 30000), result.provider);
    res.json(result);
  } catch (e) { console.error(e); res.status(e.status || 500).json({ error: e.message || 'Erreur interne du serveur TORIPE.' }); }
});
app.get('/api/history', auth, (req, res) => {
  const clientId = String(req.query.client_id || 'anonymous').slice(0, 100);
  const rows = db.prepare('SELECT role, content, created_at FROM conversations WHERE client_id = ? ORDER BY id DESC LIMIT 100').all(clientId).reverse();
  res.json({ ok: true, messages: rows });
});
app.post('/api/generate-image', auth, async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'Décris l’image à créer.' });
    if (!process.env.IMAGE_API_URL) return res.status(503).json({ error: 'Aucun fournisseur de génération d’image n’est configuré. Le chat IA peut fonctionner séparément.' });
    const headers = { 'Content-Type': 'application/json' };
    if (process.env.IMAGE_API_KEY) headers.Authorization = `Bearer ${process.env.IMAGE_API_KEY}`;
    const r = await fetch(process.env.IMAGE_API_URL, { method: 'POST', headers, body: JSON.stringify({ prompt }) });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(502).json({ error: data.error || `Fournisseur image HTTP ${r.status}` });
    res.json(data);
  } catch (e) { res.status(502).json({ error: e.message || 'Génération image indisponible.' }); }
});
app.use((err, _req, res, _next) => { console.error(err); res.status(400).json({ error: 'Requête invalide ou trop volumineuse.' }); });
app.listen(PORT, '0.0.0.0', () => console.log(`TORIPE IA CRÉATEUR API listening on ${PORT}; database=${dbPath}`));
