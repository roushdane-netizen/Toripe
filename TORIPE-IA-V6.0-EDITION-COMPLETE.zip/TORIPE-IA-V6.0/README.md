# TORIPE IA V6.0 — Édition complète unifiée

Créée par Roushdane ABOUDOU.

## Base officielle et conservation

La V6.0 reprend la V5.0 (HUB, 18 studios, assistant ORB, chat, bibliothèque,
compte, réglages, support et backend). Les archives V3.1 et V3.2 sont conservées
dans `BACKUP/`. La comparaison des fonctions JavaScript montre que la V5.0 inclut
toutes les fonctions repérées dans V3.2 ; la V3.1 est également conservée en archive.
La sauvegarde V4.0 d'origine reste incluse dans `BACKUP/`.

## Fonctions disponibles dans le projet

- Chat IA, historique local et historique serveur SQLite.
- 18 studios : chat, design, code, documents, diaporamas, apprentissage,
  traduction, réseaux sociaux, jeux, recherche, automatisation et espaces média.
- Assistant vocal ORB, dictée vocale et lecture vocale selon les capacités de l'appareil.
- Lecture de PDF, DOCX, TXT, MD et CSV depuis l'espace Documents.
- Analyse d'images jointes au chat si Gemini ou OpenAI est configuré.
- Recherche Web via Gemini si `ENABLE_WEB_SEARCH=true` et si le modèle/compte le permet.
- Export de conversations et de données, support client administrable.
- Application Android WebView et compilation APK via GitHub Actions.

## Ce qui doit être configuré pour faire fonctionner l'IA

Le backend Node.js 20+ doit être déployé. Dans `backend/` :

```bash
npm install
cp .env.example .env
npm start
```

Configure ensuite les variables secrètes sur ton hébergeur (ou dans `.env` pour un
test local) :

- `GEMINI_API_KEY` : clé Gemini obtenue sur Google AI Studio.
- `GEMINI_MODEL` : modèle Gemini disponible sur ton compte.
- `OPENAI_API_KEY` : facultatif ; l'API OpenAI peut être payante.
- `GPT_MODEL`, `GPT_BALANCED_MODEL`, `GPT_PRO_MODEL` : identifiants réels des modèles
  auxquels ton compte a accès.
- `TORIPE_ACCESS_TOKEN` : jeton d'accès à l'API de l'application.
- `TORIPE_ADMIN_TOKEN` : jeton administrateur pour gérer le support.
- `ENABLE_WEB_SEARCH=true` : active la tentative de recherche Web Gemini.
- `IMAGE_API_URL` et `IMAGE_API_KEY` : adaptateur externe facultatif pour la création
  réelle d'images.

**Important : TORIPE IA ne peut pas fabriquer ou délivrer les clés API de Google,
OpenAI ou d'autres fournisseurs.** Les clés sont créées dans les comptes officiels
des fournisseurs. Certains proposent des quotas gratuits, mais leur disponibilité,
leurs limites et les conditions de carte bancaire peuvent changer. N'inscris jamais
une clé dans le HTML ou dans l'APK.

## Configuration de l'application

Dans TORIPE IA > Paramètres, renseigne l'URL HTTPS du backend, par exemple
`https://ton-serveur.example/api/chat`, puis le `TORIPE_ACCESS_TOKEN` si tu l'as activé.
Le serveur répond sur `/health`.

## Limites actuelles à ne pas confondre avec les fonctions actives

- Les studios vidéo, musique, 3D, montage et photo peuvent préparer des briefs,
  prompts ou plans ; le rendu média final exige un service spécialisé.
- La génération d'images réelle dépend de `IMAGE_API_URL`.
- L'analyse de PDF/DOCX se fait dans l'espace Documents ; le chat direct prend en charge
  les images et petits fichiers texte.
- La voix dépend des API du navigateur et des permissions Android.
- Les conversations locales restent sur l'appareil ; la sauvegarde serveur dépend du
  backend et de son stockage persistant.

## Compiler l'APK

Pousse le projet dans un dépôt GitHub, puis ouvre Actions et lance
« Construire APK TORIPE IA ». Télécharge l'artefact `TORIPE-IA-APK-debug` si le workflow
réussit. Aucun APK précompilé n'est inclus dans cette archive.

Consulte `CHANGELOG-V6.0.txt` et `backend/README.md`.
