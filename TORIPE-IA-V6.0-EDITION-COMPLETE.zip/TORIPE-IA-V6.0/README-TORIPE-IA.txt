TORIPE IA V6.0 — ÉDITION COMPLÈTE UNIFIÉE

La V6.0 reprend la V5.0 comme base et conserve les archives V3.1, V3.2 et V4.0 dans BACKUP. Les améliorations V6 sont décrites dans CHANGELOG-V6.0.txt. Voir README.md pour l'installation, la configuration des clés côté serveur, les limites et la compilation APK.

Créée par Roushdane ABOUDOU.
